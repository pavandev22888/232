"""Reassemble ZIP-wrapped parts; original DLLs are not executed."""
from pathlib import Path
import argparse,json,hashlib,zipfile,sys
EXPECTED_SHA256='b5e3336edaa99b6f437f22368ab230107b7b781d9dfd54c83c6e00d9cfb8018f'
p=argparse.ArgumentParser();p.add_argument('--parts-dir',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output',type=Path);p.add_argument('--manifest',type=Path,default=Path(__file__).resolve().parent/'PARTS_MANIFEST.json');a=p.parse_args();m=json.loads(a.manifest.read_text(encoding='utf-8'))
if m['full_archive_sha256']!=EXPECTED_SHA256:raise SystemExit('Wrong part manifest.')
found={}
for path in sorted(a.parts_dir.glob('*.zip')):
 if not zipfile.is_zipfile(path):continue
 with zipfile.ZipFile(path) as z:
  if 'PART_NUMBER.json' not in z.namelist():continue
  part=json.loads(z.read('PART_NUMBER.json'))
  if part.get('full_archive_sha256')!=EXPECTED_SHA256:continue
  n=part['number']
  if n in found:raise SystemExit('Duplicate part number '+str(n))
  found[n]=path
missing=[d['number'] for d in m['parts'] if d['number'] not in found]
if missing:raise SystemExit('Missing parts: '+', '.join(map(str,missing)))
if len(found)!=m['part_count']:raise SystemExit('Unexpected number of parts.')
out=a.output or a.parts_dir/m['full_archive_name'];out.parent.mkdir(parents=True,exist_ok=True)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
if out.exists():
 if out.stat().st_size==m['full_archive_bytes'] and digest(out)==EXPECTED_SHA256:print('Already assembled and verified:',out);sys.exit(0)
 raise SystemExit('Output exists but differs; it will not be overwritten.')
tmp=out.with_name(out.name+'.partial')
if tmp.exists():raise SystemExit('An incomplete .partial output exists. Inspect it before retrying.')
whole=hashlib.sha256();total=0
with tmp.open('wb') as w:
 for d in m['parts']:
  h=hashlib.sha256();n=0
  with zipfile.ZipFile(found[d['number']]) as z,z.open(d['payload']) as f:
   for b in iter(lambda:f.read(4*1024*1024),b''):w.write(b);whole.update(b);h.update(b);n+=len(b)
  if n!=d['bytes'] or h.hexdigest()!=d['sha256']:raise SystemExit('Part checksum mismatch: '+str(d['number']))
  total+=n;print('Verified part',d['number'],'of',m['part_count'],flush=True)
if total!=m['full_archive_bytes'] or whole.hexdigest()!=EXPECTED_SHA256:raise SystemExit('Combined archive checksum mismatch.')
tmp.replace(out);print('READY:',out);print('SHA256:',whole.hexdigest());print('Unzip the assembled archive and follow PROMPT_ДЛЯ_АГЕНТА.txt inside it.')
